import React, { useState } from 'react';
import './ListaPelis.css';

function ListaPelis({ movies }) {
  const [trailerVisible, setTrailerVisible] = useState(null);

  
  const toggleTrailer = (index) => {
    setTrailerVisible(trailerVisible === index ? null : index);
  };

  return (
    <div className="lista-pelis">
      <ul>
        {movies.map((movie, index) => (
          <li key={index}>
            {movie.title} ({movie.year})
            <button onClick={() => toggleTrailer(index)}>
              {trailerVisible === index ? 'Ocultar Tráiler' : 'Ver Tráiler'}
            </button>
            {trailerVisible === index && (
              <iframe
                width="560"
                height="315"
                src={movie.trailer.replace("https://youtu.be/", "https://www.youtube.com/embed/")}
                title={movie.title}
                allowFullScreen
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              ></iframe>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ListaPelis;
