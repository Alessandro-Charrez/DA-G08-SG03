import React from 'react';
import './Footer.css'
function Footer({ year }) {
  return <footer className="footer">© {year} Todos los derechos reservados</footer>;
}

export default Footer;