import React from 'react';
import './Header.css'
function Header() {
  return <h1 className="header">Trailer de Peliculas</h1>;
}

export default Header;
