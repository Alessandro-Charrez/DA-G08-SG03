import React from 'react';
import { Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <div className="container text-center">
      <h1>Pagina Web usando NPM y Node.js</h1>
      <p>Este boton fue creado usando React Bootstrap, instalado a traves de NPM:</p>
      <Button >Presiona click estimado</Button>
    </div>
  );
}

export default App;