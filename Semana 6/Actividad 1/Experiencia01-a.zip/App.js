import React from 'react';

function App() {
  return (
    <div className="container">
      <h1 className="text-center my-4">Trailer Ciencia Ficcion de Terror</h1>
      <p className="text-center">Visualizacion de los trailers de dos peliculas</p>
      
      <ul className="list-group">
        <li className="list-group-item">
          <a 
            href="https://www.youtube.com/watch?v=svnAD0TApb8" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-primary"
          >
            <i className="fas fa-film"></i> Ver Trailer de Alien: Covenant
          </a>
        </li>
        <li className="list-group-item">
          <a 
            href="https://youtu.be/5UEv03g51kU" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-primary"
          >
            <i className="fas fa-film"></i> Ver Trailer de Prometheus
          </a>
        </li>
      </ul>
    </div>
  );
}

export default App;
