import React from 'react';
import './MainContent.css';

const MainContent = () => {

    const personajes = [
        { id: 1, nombre: 'Daniels', rol: 'Jefa de terraformación' },
        { id: 2, nombre: 'Walter', rol: 'Android' },
        { id: 3, nombre: 'Tennessee', rol: 'Piloto de la nave' },
        { id: 4, nombre: 'David', rol: 'Android (anterior)' }
    ];

    return (
        <main className="main-content">
            <h2>Personajes de Alien Covenant</h2>
            <ul>
                {personajes.map(personaje => (
                    <li key={personaje.id}>
                        <strong>{personaje.nombre}</strong>: {personaje.rol}
                    </li>
                ))}
            </ul>
        </main>
    );
};

export default MainContent;