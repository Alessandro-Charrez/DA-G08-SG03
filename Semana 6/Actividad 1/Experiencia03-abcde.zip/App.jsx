
import React from 'react';
import Header from './Header';
import ListaPelis from './ListaPelis'; 
import Footer from './Footer';

function App() {
  const movies = [
    { title: 'Alien: Covenant', year: 2017, trailer: 'https://youtu.be/zM_8SvQXBso' },
    { title: 'Prometheus', year: 2012, trailer: 'https://youtu.be/5UEv03g51kU' },
  ];
  const currentYear = new Date().getFullYear();

  return (
    <div>
      <Header />
      <ListaPelis movies={movies} /> 
      <Footer year={currentYear} />
    </div>
  );
}

export default App;
