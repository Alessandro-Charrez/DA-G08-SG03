import React from 'react';
import './ListaPelis.css';

function ListaPelis({ movies }) {
  const handleClick = (trailerUrl) => {
    window.open(trailerUrl, '_blank'); 
  };

  return (
    <div className="lista-pelis">
      <ul>
        {movies.map((movie, index) => (
          <li key={index}>
            {movie.title} ({movie.year})
            <button onClick={() => handleClick(movie.trailer)}>Ver Trailer</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ListaPelis;