const express = require('express');
const jwt = require('jsonwebtoken');
const app = express();

// Middleware para verificar el token
function verifiToken(req, res, next) {
    const bearerHeader = req.headers['authorization']; // Obtener el header Authorization

    if (typeof bearerHeader !== 'undefined') {
        // Separar 'Bearer' y el token
        const bearer = bearerHeader.split(' ');
        const bearerToken = bearer[1]; // El token es la segunda parte después de 'Bearer'
        req.token = bearerToken; // Asignamos el token a la solicitud
        next(); // Continuamos con el siguiente middleware
    } else {
        res.sendStatus(403); // Si no hay token, devolvemos un error 403
    }
}

app.get('/api', (req, res) => {
    res.json({
        mensaje: "Esta es la data de clientes"
    });
});

// Ruta protegida con el middleware verifiToken
app.post('/api/posts', verifiToken, (req, res) => {
    jwt.verify(req.token, 'secretkey', (err, authData) => {
        if (err) {
            res.sendStatus(403); // Si el token no es valido, devolvemos un error 403
        } else {
            res.json({
                mensaje: "Post creado..",
                authData // Devuelve la información de autenticacion del token
            });
        }
    });
});

// Ruta para login y generación de token
app.post('/api/login', (req, res) => {
    const user = {
        id: 1,
        username: "aruiz",
        email: "aruiz@gmail.com"
    };

    jwt.sign({ user }, 'secretkey', { expiresIn: '50s' }, (err, token) => {
        if (err) {
            res.sendStatus(500); // Si hay un error generando el token, devolvemos un error 500
        } else {
            res.json({
                token // Retornamos el token generado
            });
        }
    });
});

app.listen(5000, () => console.log("Servidor se está ejecutando en el puerto 5000"));
