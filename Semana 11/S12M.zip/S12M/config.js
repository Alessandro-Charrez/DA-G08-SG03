const mongoose = require('mongoose');


const connectDB = async () => {
    try {
        await mongoose.connect('mongodb://127.0.0.1:27017/users_db');
        console.log('Conexion exitosa a la bd');
    } catch (err) {
        console.error('Error al conectar a MongoDB', err);
        process.exit(1);  
    }
};

module.exports = connectDB;
