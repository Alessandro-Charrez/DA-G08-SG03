const express = require('express');
const bodyParser = require('body-parser');
const User = require('./models/User');
const connectDB = require('./config');  // Importamos la configuración de la base de datos

const app = express();


app.use(bodyParser.json());


connectDB();  

app.post('/users', async (req, res) => {
    const { name, email, age } = req.body;


    if (!name || !email || !age) {
        return res.status(400).json({ message: 'Por favor, ingrese todos los campos requeridos: name, email, age.' });
    }

    try {
        const newUser = new User({ name, email, age });
        await newUser.save();
        res.status(201).json({ message: 'Usuario creado con exito', user: newUser });
    } catch (err) {
        res.status(500).json({ message: 'Error al crear el usuario', error: err });
    }
});


app.put('/users/:id', async (req, res) => {
    const { id } = req.params;
    const { name, email, age } = req.body;

    try {
        const updatedUser = await User.findByIdAndUpdate(id, { name, email, age }, { new: true });
        if (!updatedUser) {
            return res.status(404).json({ message: 'Usuario no encontrado' });
        }
        res.json(updatedUser);
    } catch (err) {
        res.status(500).json({ message: 'Error al actualizar el usuario', error: err });
    }
});


app.delete('/users/:id', async (req, res) => {
    const { id } = req.params;

    try {
        const deletedUser = await User.findByIdAndDelete(id);
        if (!deletedUser) {
            return res.status(404).json({ message: 'Usuario no encontrado' });
        }
        res.json({ message: 'Usuario eliminado con exito' });
    } catch (err) {
        res.status(500).json({ message: 'Error al eliminar el usuario', error: err });
    }
});


app.listen(3001, () => {
    console.log(`Servidor escuchando en el puerto 3001`);
});
