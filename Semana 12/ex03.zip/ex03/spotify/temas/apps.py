from django.apps import AppConfig


class TemasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'temas'
