from django.db import models

class Album(models.Model):
    album_name = models.CharField(max_length=100)  # Corregido 'album name' a 'album_name'
    artist = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.album_name} by {self.artist}"

class Track(models.Model):
    album = models.ForeignKey(Album, related_name='tracks', on_delete=models.CASCADE) 
    title = models.CharField(max_length=100)
    duration = models.IntegerField()

    class Meta:
        unique_together = ['album', 'order']  
        ordering = ['order']

    def __str__(self):
        return f"Track {self.order}: {self.title}"
