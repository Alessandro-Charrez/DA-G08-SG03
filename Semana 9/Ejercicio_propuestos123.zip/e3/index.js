// Importar los paquetes http y fs
var http = require('http'),
    fs = require('fs');

// Cargar la plantilla HTML desde el archivo
var html = fs.readFileSync("./index.html");

// Crear servidor, ponerlo a la escucha en el puerto 3000 y servir el contenido HTML
http.createServer(function(req, res) {
    res.write(html);
    res.end();
}).listen(3000, function() {
    console.log("Servidor corriendo en el puerto 3000");
});