
var mysql = require('mysql');

var con = mysql.createConnection({
    host: 'localhost',
    port: '3306',
    database: 'carcel',
    user: 'root',
    password: '',
});

con.connect(function (err) {
    if (err) {
        console.log("Error de conexion" + err.stack);
        return;
    }
    console.log("Conectado al ID " + con.threadId);
});
con.query('select * from reclusos', function (error, results) {
    if (error)
        throw error;
    results.forEach(element => {
        console.log(element);
    });
});
con.end();