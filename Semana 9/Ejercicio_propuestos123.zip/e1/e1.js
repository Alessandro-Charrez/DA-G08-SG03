
const http = require('http');

const server = http.createServer();

function responder(peticion, respuesta) {
  respuesta.writeHead(200, { 'Content-Type': 'text/plain' });
  respuesta.write('Rafael Del Arroyo');
  respuesta.end();
}

server.on('request', responder);

server.listen(4000, function () {
  console.log('Funcionando en el 4000 :u');
});
